#include "caffe.pb.h"
#include <google/protobuf/io/coded_stream.h>
#include <google/protobuf/io/zero_copy_stream_impl.h>
#include <google/protobuf/io/gzip_stream.h>
#include <google/protobuf/text_format.h>

#include <fstream>
#include <iostream>
#include <iosfwd>
#include <sys/stat.h>
#include <cmath>
#include <iostream>
#include <memory>
#include <fcntl.h>

using namespace caffe;
using namespace std;

using google::protobuf::io::FileInputStream;
using google::protobuf::io::FileOutputStream;
using google::protobuf::io::ZeroCopyInputStream;
using google::protobuf::io::CodedInputStream;
using google::protobuf::io::ZeroCopyOutputStream;
using google::protobuf::io::CodedOutputStream;
using google::protobuf::io::GzipOutputStream;
using google::protobuf::Message;

#define SHOW_VALUE 0
bool isScoreBigger(pair<int, float>& a, pair<int, float>& b)
{
    return a.second > b.second;
}
vector<pair<int, float>> AddArrAbs(float* arr, int len, int step)
{
    vector<pair<int, float>> sums(len / step);
    int index = 0;
    float sum = 0;

    for (size_t i = 0; i < len; i++)
    {
        sum += arr[i];

        if (i % step == 0)
        {
            sums[index] = make_pair(index, std::abs(sum));
            sum = 0;
            index++;
        }

    }
    //cout << sums.size();
    return sums;
}

void SetData(BlobProto* blob, const vector<int>& remainedKer,
    int numPerKer, int newChannelNum)
{
    vector<float> buffer(newChannelNum * numPerKer);

    float* data = blob->mutable_data()->mutable_data();

    for (int k = 0; k < remainedKer.size(); k++)
    {
        memcpy(&buffer[k * numPerKer],
            data + remainedKer[k] * numPerKer, numPerKer * sizeof(float));
    }
    if (numPerKer > 1)
    {

        blob->set_num(newChannelNum);
    }
    else
    {
        blob->set_width(newChannelNum);

    }

    blob->mutable_data()->Clear();

    for (size_t k = 0; k < buffer.size(); k++)
    {
        blob->mutable_data()->Add(buffer[k]);
    }
}
vector<int> PruneCurLayer(BlobProto* blob, int numPerKer, int newChannelNum)
{
    //1 绝对值求和
    vector<pair<int, float>> sums = AddArrAbs(blob->mutable_data()->mutable_data(),
        blob->data_size(), numPerKer);
    //2 排序
    sort(sums.begin(), sums.end(), isScoreBigger);
    vector<int> remainedKer;
    for (size_t k = 0; k < newChannelNum; k++)
    {
        remainedKer.push_back(sums[k].first);
    }

    //3 剪枝当前层
    SetData(blob, remainedKer, numPerKer, newChannelNum);


    return remainedKer;
}

void PruneNextLayer(BlobProto* blob, const vector<int>& lastRemainedKer,
    int lastKerNum, int newChannelNum, int kerLen)
{
    int numPerKer = lastKerNum * kerLen;
    float* data = blob->mutable_data()->mutable_data();

    vector<float> buffer(newChannelNum * lastKerNum * kerLen);

    for (size_t k = 0; k < newChannelNum; k++)
    {
        for (size_t h = 0; h < lastKerNum; h++)
        {
            memcpy(&buffer[k * numPerKer + h * kerLen],
                data + k * numPerKer + lastRemainedKer[h] * kerLen, kerLen * sizeof(float));
        }
    }


    blob->set_channels(lastKerNum);

    blob->mutable_data()->Clear();
    for (size_t k = 0; k < buffer.size(); k++)
    {
        blob->mutable_data()->Add(buffer[k]);
    }

}
vector<int> computeNumPerKer(NetParameter& net)
{
    vector<int> numPerKers;
    for (size_t i = 0; i < net.layers_size(); i++)
    {
        V1LayerParameter& param = *net.mutable_layers(i);

        if (param.type() == V1LayerParameter_LayerType_CONVOLUTION)
        {
            BlobProto* blob = param.mutable_blobs(0);
            int numPerKer = blob->data_size() / blob->num();
            numPerKers.push_back(numPerKer);
        }

    }

    return numPerKers;
}

int main(){
    vector<int> oldChannelsNums = { 64, 64, 128, 128, 256, 256, 256, 512, 512, 512, 512, 512, 512 };
    vector<int> newChannelsNums = { 32, 64, 128, 128, 256, 256, 256, 256, 256, 256, 256, 256, 256 };
    string path = "/home/lsn/code/reduceModel/";

#if SHOW_VALUE
    const char* fileOutPath = "save1.caffemodel";
    const char* infile = "save.caffemodel";
#else
    const char* fileOutPath = "/home/lsn/code/reduceModel/save.caffemodel";
    const char* infile = "/home/lsn/code/reduceModel/VGG_ILSVRC_16_layers.caffemodel";
#endif
    int fd = open(infile, O_RDONLY);
    if (fd == -1) return false;
    std::shared_ptr<ZeroCopyInputStream> raw_input = std::make_shared<FileInputStream>(fd);
    std::shared_ptr<CodedInputStream> coded_input = std::make_shared<CodedInputStream>(raw_input.get());
    coded_input->SetTotalBytesLimit(INT_MAX, 536870912);

    NetParameter net;

    bool success = net.ParseFromCodedStream(coded_input.get());
    coded_input.reset();
    raw_input.reset();
    close(fd);

    net.mutable_state()->set_phase(caffe::Phase::TEST);

    bool isPreLayerPrued = false;
    int lastKerNum = -1;

    int convLayerIndex = 0;
    vector<int> numPerKers = computeNumPerKer(net);
    vector<int> lastRemainedKer;

    for (int i = 0; i < net.layers_size(); ++i)
    {
        V1LayerParameter& param = *net.mutable_layers(i);
        int newChannelNum = newChannelsNums[convLayerIndex];
        int oldChannelsNum = oldChannelsNums[convLayerIndex];
        if (param.type() == V1LayerParameter_LayerType_CONVOLUTION)
        {
#if SHOW_VALUE
            printf("layer: %s\n", param.name().c_str());
            for (int j = 0; j < param.blobs_size(); j++)
            {
                BlobProto* blob = param.mutable_blobs(j);
                cout << "shape: " << blob->num() << " " << blob->channels()
                    << " " << blob->width() << " " << blob->height() << endl;

                int ch = blob->data_size();
                cout << ch << endl;

            }
#else
            if (oldChannelsNum != newChannelNum)
            {

                vector<int> kerLen = { 9, 1 };
                int blobSize = param.blobs_size();
                for (int j = 0; j < blobSize; j++)
                {
                    BlobProto* blob = param.mutable_blobs(j);

                    int numPerKer = numPerKers[convLayerIndex];
                    numPerKer = j == 0 ? numPerKer : 1;
                    vector<int> remainedKer = PruneCurLayer(blob, numPerKer, newChannelNum);

                    if (j == 0)
                    {
                        lastKerNum = newChannelNum;

                        lastRemainedKer.clear();
                        copy(remainedKer.begin(), remainedKer.end(), back_inserter(lastRemainedKer));
                    }

                    //bias 的的channel为1，不需要PruneNextLayer
                    if (isPreLayerPrued && j == 0)
                    {
                        PruneNextLayer(blob, lastRemainedKer, lastKerNum, newChannelNum, kerLen[j]);

                        isPreLayerPrued = false;
                        // << convLayerIndex << endl;

                    }

                    if (j == blobSize - 1)
                    {
                        isPreLayerPrued = true;
                    }

                    //cout << blob->data_size() << endl;
                }
            }
            else
            {
                //4 剪枝下一层
                if (isPreLayerPrued)
                {
                    int kerLen = 9;

                    BlobProto* blob = param.mutable_blobs(0);
                    PruneNextLayer(blob, lastRemainedKer, lastKerNum, newChannelNum, kerLen);
                    isPreLayerPrued = false;

                    //cout << blob->data_size() << endl;

                }
            }

            if (convLayerIndex < oldChannelsNums.size() -1)
            {
                convLayerIndex++;
            }
#endif
        }
    }


    fstream output(fileOutPath, ios::out | ios::trunc | ios::binary);
    success = net.SerializePartialToOstream(&output);
    cout << "finish!" << endl;
    getchar();
    return 0;
}
